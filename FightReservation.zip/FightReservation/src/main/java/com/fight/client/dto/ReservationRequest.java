package com.fight.client.dto;

import lombok.Data;

@Data
public class ReservationRequest {

	private int flightId;
	private String passenerFirstName;
	private String passenerLastName;
	private String passeneremail;
	private String passenerPhone;
	private String nameOnTheCard;
	private String cardNo;
	private String expiryDate;
	private String securityCode;
}
