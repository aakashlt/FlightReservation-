package com.fight.client.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.fight.client.dao.PassengerDao;
import com.fight.client.dto.ReservationRequest;
import com.fight.client.model.Passenger;
import com.fight.client.model.Reservation;
import com.fight.model.Flight;
import com.fight.service.FlightService;
import com.fight.service.ReservationService;

@Controller
@RequestMapping("/flights")
public class ReservationController {

	@Autowired
	FlightService flightservie;

	@Autowired
	ReservationService reservationService;

	@Autowired
	PassengerDao passengerDao;
	
	@RequestMapping("/showCompleteReservation")
	public String showCompleteReservation(@RequestParam("flightId") int flightId, ModelMap modelMap) {
		Flight flight = flightservie.findeFlightById(flightId);
		modelMap.addAttribute("flight", flight);
		return "completeReservation";
	}
	
	@RequestMapping("/reservationCancel")
	public String reservationCancel(@RequestParam("reservationId") int reservationId, ModelMap modelMap) {
		Reservation reservation;
		reservation  = reservationService.findReservationrById(reservationId);
		int passengerId = reservation.getPassengerId();
		passengerDao.deletePassenger(passengerId);
		reservationService.deleteReservation(reservationId);
		modelMap.addAttribute("msg", "your reservation has been cancled for id"+reservationId);
		return "reservationCancel";
	}

	@RequestMapping(value = "/conf", method = RequestMethod.POST)
	public String completeReservation(ReservationRequest reservationRequest, ModelMap modelMap) {

		Flight flight = flightservie.findeFlightById(reservationRequest.getFlightId());

		Passenger passenger = new Passenger();
		passenger.setFirstName(reservationRequest.getPassenerFirstName());
		passenger.setLastName(reservationRequest.getPassenerLastName());
		passenger.setMiddleName(reservationRequest.getPassenerLastName());
		passenger.setEmail(reservationRequest.getPasseneremail());
		passenger.setPhone(reservationRequest.getPassenerPhone());
		Passenger passenger2 = passengerDao.addPassenger(passenger);
		int id = passenger2.getId();
		System.out.println(passenger2.getId());
		Reservation reservation = new Reservation();
		reservation.setPassengerId(id);
		reservation.setFlightId(flight.getFlightId());
		Reservation addReservation = reservationService.addReservation(reservation);
		int reservationId = addReservation.getId();
		System.out.println("reservation Id==>"+reservationId);
		Reservation reservation_user = new Reservation();
		reservation_user  = reservationService.findReservationrById(reservationId);
		System.out.println("reservation obj==>"+reservation_user);
		Passenger passenger_user = passengerDao.findPassengerById(reservation.getPassengerId());
		Flight flight_user = flightservie.findeFlightById(reservationRequest.getFlightId());

		System.out.println(reservation_user);
		System.out.println(passenger_user);
		System.out.println(flight_user);
		modelMap.addAttribute("reservation_user", reservation_user);
		modelMap.addAttribute("passenger_user", passenger_user);
		modelMap.addAttribute("flight", flight_user);
		return "conf";
	}
}
