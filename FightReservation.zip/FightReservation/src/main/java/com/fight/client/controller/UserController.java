package com.fight.client.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.fight.client.model.User;
import com.fight.client.service.UserService;

@Controller
//@RequestMapping("/User")
public class UserController {

	@Autowired
	UserService userservice;
	
	@RequestMapping(value = { "/showRegistration" }, method = RequestMethod.GET)
	public ModelAndView ShowRegistration() {
		ModelAndView model = new ModelAndView();
		model.setViewName("login/registerUser");
		return model;
	}
	
	@RequestMapping(value = "/registerUser", method = RequestMethod.POST)
	public ModelAndView saveOrUpdate(@ModelAttribute("user") User user) {
		if(user != null) {
			userservice.addUser(user);
		}
//		else {
//			return new ModelAndView("/login/registerUser");
//		}
		return new ModelAndView("/login/login");
	}
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView login(@RequestParam("email") String email,@RequestParam("password") String password,ModelMap modelMap ) {
		User user = userservice.findByEmail(email);
		if(user.getPassword().equals(password)) {
			return new ModelAndView("/findFlight");
		}
		else {
			modelMap.addAttribute("msg", "Invalid Usernme or Password");
		}
		return new ModelAndView("/login/login");
	}
}

