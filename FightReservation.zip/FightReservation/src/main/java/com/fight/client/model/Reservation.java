package com.fight.client.model;

import lombok.Data;

@Data
public class Reservation {
	private int id;
	private Boolean checkedIn;
	private int numberOfBags;
	private int passengerId;
	private int flightId;

}
