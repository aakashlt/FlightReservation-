package com.fight.model;

import lombok.Data;

@Data
public class Flight {

	private int flightId;
	private String flightName;
	private String departure;
	private String arrival;
	private String departureDate;
	private String arrivalDate;
}
