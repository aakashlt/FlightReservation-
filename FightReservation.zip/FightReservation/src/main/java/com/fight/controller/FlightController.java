package com.fight.controller;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.fight.model.Flight;
import com.fight.service.FlightService;

@Controller
@RequestMapping("/flights")
public class FlightController {

	@Autowired
	FlightService flightservie;

	@RequestMapping(value = { "/", "/flightsList" }, method = RequestMethod.GET)
	public ModelAndView getAllFlights() {
		ModelAndView model = new ModelAndView();
		List<Flight> list = flightservie.getAllFlights();
		
		model.addObject("flightsList", list);
		model.setViewName("flights_list");
		return model;
	}

	@RequestMapping(value = "/update/{id}", method = RequestMethod.GET)
	public ModelAndView editEmployee(@PathVariable int id) {
		ModelAndView model = new ModelAndView();

		Flight flight = flightservie.findeFlightById(id);
		model.addObject("flightForm", flight);

		model.setViewName("flight_form");
		return model;
	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public ModelAndView addEmployee() {
		ModelAndView model = new ModelAndView();

		Flight flight = new Flight();
		model.addObject("flightForm", flight);

		model.setViewName("flight_form");
		return model;
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ModelAndView saveOrUpdate(@ModelAttribute("flightForm") Flight flight) {
		if (flight.getFlightId() != 0) {
			flightservie.updateFlight(flight);
		} else {
			flightservie.addFlight(flight);
		}
		return new ModelAndView("redirect:/flights/flightsList");
	}

	@RequestMapping(value = "/delete/{id}", method = RequestMethod.GET)
	public ModelAndView deleteEmployee(@PathVariable("id") int id) {
		flightservie.deleteFlight(id);
		return new ModelAndView("redirect:/flights/flightsList");
	}
	
	//client search
	@RequestMapping(value = "/findFlight", method = RequestMethod.POST)
	public ModelAndView findFlight(@RequestParam("departure") String departure,
			@RequestParam("arrival") String arrival,
		ModelMap modelMap) {
		List<Flight> flight = flightservie.findeFlightByDepartureDate(departure, arrival);
		modelMap.addAttribute("flights",flight);
		return new ModelAndView("displayFlights");
	}
}
