package com.fight;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FightReservationApplication {

	public static void main(String[] args) {
		SpringApplication.run(FightReservationApplication.class, args);
		 
	}

}
