package com.fight;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FightReservationApplicationTests {

	@Test
	void contextLoads() {
	}

}
